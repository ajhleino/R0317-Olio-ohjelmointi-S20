import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.JTextField;

public class GUI_Automaatti extends JFrame {

	// Luokkamuuttujat
	// Esitell��n t��ll� jotta komponentteihin voidaan viitata mist� tahansa luokan
	// sis�lt�

	JPanel contentPane;
	private JMenuItem mntmTallennaAutomaatinTila;
	private JMenuItem mntmLataaAutomaatti;

	/**
	 * Main-metodi, joka k�ynnist�� sovelluksen
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					// Luodaan ensmin uusi JuomaAutomaatti-olio
					JuomaAutomaatti ja = new JuomaAutomaatti();

					// K�ytt�liittym� saa parametrina olion, jonka tiedot se n�ytt��
					GUI_Automaatti frame = new GUI_Automaatti(ja);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Konstruktorissa rakennetaan k�ytt�liittym�. Huomaa, ett� otetaan parametrina
	 * vastaan alussa luotu juoma-automaatti. T�m� siksi, ett� voidaan n�ytt�� sen
	 * tiedot GUI:ssa
	 */
	public GUI_Automaatti(JuomaAutomaatti ja) {

		// Ikkunan otsikko ja koko

		setTitle("Kahviautomaatti GUI v. 1.0");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 465, 705);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu yllapitoMenu = new JMenu("Yll\u00E4pito");
		yllapitoMenu.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		menuBar.add(yllapitoMenu);

		JMenuItem menuItem1 = new JMenuItem("Aseta kahvin m\u00E4\u00E4r\u00E4");
		menuItem1.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		yllapitoMenu.add(menuItem1);

		JMenuItem menuItem2 = new JMenuItem("Aseta teen m\u00E4\u00E4r\u00E4");
		menuItem2.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		yllapitoMenu.add(menuItem2);

		JMenuItem menuItem3 = new JMenuItem("Aseta kaakaon m\u00E4\u00E4r\u00E4");
		menuItem3.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		yllapitoMenu.add(menuItem3);

		JMenuItem menuItem4 = new JMenuItem("Tallenna automaatin tila");
		menuItem4.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		yllapitoMenu.add(menuItem4);

		JMenuItem menuItem5 = new JMenuItem("Lataa automaatti");
		menuItem5.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		yllapitoMenu.add(menuItem5);

		JMenuItem menuItem6 = new JMenuItem("Lopeta");
		menuItem6.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		yllapitoMenu.add(menuItem6);

		JMenu tietojaMenu = new JMenu("Tietoja ohjelmasta");
		tietojaMenu.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		menuBar.add(tietojaMenu);

		JMenuItem tietoMenu1 = new JMenuItem("Versiotiedot");
		tietoMenu1.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		tietojaMenu.add(tietoMenu1);

		JMenuItem tietoMenu2 = new JMenuItem("Ohje");
		tietoMenu2.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		tietojaMenu.add(tietoMenu2);

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton kahviNappi = new JButton("Kahvi");
		kahviNappi.setFont(new Font("Tahoma", Font.PLAIN, 16));
		kahviNappi.setBounds(15, 47, 139, 132);
		contentPane.add(kahviNappi);
		kahviNappi.setIcon(new ImageIcon("img\\coffee.jpg"));

		JButton teeNappi = new JButton("Tee");
		teeNappi.setFont(new Font("Tahoma", Font.PLAIN, 16));
		teeNappi.setBounds(15, 238, 139, 132);
		contentPane.add(teeNappi);
		teeNappi.setIcon(new ImageIcon("img\\tea.jpg"));

		JButton kaakaoNappi = new JButton("Kaakao");
		kaakaoNappi.setFont(new Font("Tahoma", Font.PLAIN, 16));
		kaakaoNappi.setBounds(15, 436, 139, 132);
		contentPane.add(kaakaoNappi);
		kaakaoNappi.setIcon(new ImageIcon("img\\cocoa.jpg"));

		JLabel kahviJLable = new JLabel("Kahvi");
		kahviJLable.setFont(new Font("Tahoma", Font.PLAIN, 16));
		kahviJLable.setBounds(59, 190, 49, 14);
		contentPane.add(kahviJLable);

		JLabel teeJLable = new JLabel("Tee");
		teeJLable.setFont(new Font("Tahoma", Font.PLAIN, 16));
		teeJLable.setBounds(59, 381, 49, 14);
		contentPane.add(teeJLable);

		JLabel kaakaoJLable = new JLabel("Kaakao");
		kaakaoJLable.setFont(new Font("Tahoma", Font.PLAIN, 16));
		kaakaoJLable.setBounds(57, 579, 63, 14);
		contentPane.add(kaakaoJLable);

		JLabel kahviaJaljella = new JLabel("Kahvia j\u00E4ljell\u00E4: " + ja.getKahvi());
		kahviaJaljella.setFont(new Font("Tahoma", Font.PLAIN, 16));
		kahviaJaljella.setBounds(235, 108, 157, 14);
		contentPane.add(kahviaJaljella);

		JLabel teetaJaljella = new JLabel("Teet\u00E4 j\u00E4ljell\u00E4:" + ja.getTee());
		teetaJaljella.setFont(new Font("Tahoma", Font.PLAIN, 16));
		teetaJaljella.setBounds(235, 299, 132, 14);
		contentPane.add(teetaJaljella);

		JLabel kaakaotaJaljella = new JLabel("Kaakaota j\u00E4ljell\u00E4: " + ja.getKaakao());
		kaakaotaJaljella.setFont(new Font("Tahoma", Font.PLAIN, 16));
		kaakaotaJaljella.setBounds(235, 497, 157, 14);
		contentPane.add(kaakaotaJaljella);

		// teht�v� 5 ja 6

		kahviNappi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				ja.valmistaKahvi();
				int maara = ja.getKahvi();
				kahviaJaljella.setText("Kahvia j�ljell�: " + maara);
				if (maara <= 20) {
					kahviaJaljella.setForeground(Color.RED);
				}
				if (maara > 20) {
					kahviaJaljella.setForeground(Color.BLACK);
				}

			}
		});

		teeNappi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				ja.valmistaTee();
				int maara = ja.getTee();
				teetaJaljella.setText("Teet� j�ljell�: " + maara);
				if (maara <= 20) {
					teetaJaljella.setForeground(Color.RED);
				}
				if (maara > 20) {
					teetaJaljella.setForeground(Color.BLACK);
				}
			}
		});

		kaakaoNappi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				ja.valmistaKaakao();
				int maara = ja.getKaakao();
				kaakaotaJaljella.setText("Kaakaota j�ljell�: " + maara);
				if (maara <= 20) {
					kaakaotaJaljella.setForeground(Color.RED);
				}
				if (maara > 20) {
					kaakaotaJaljella.setForeground(Color.BLACK);
				}
			}
		});

		// teht�v� 8
		menuItem1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean kysely1;

				while (kysely1 = true) {
					String uusiArvo = JOptionPane.showInputDialog( "Anna uusi arvo: ");
					int uusiKahvi = Integer.parseInt(uusiArvo);
					if (uusiKahvi < 250 && uusiKahvi > 0) {
						ja.setKahvi(uusiKahvi);
						kahviaJaljella.setText("Kahvia j�ljell�: " + uusiKahvi);
						kahviaJaljella.setForeground(Color.BLACK);
						if (uusiKahvi <= 20) {
							kahviaJaljella.setForeground(Color.RED);
						}
						break;
					} else if(uusiKahvi>=250 || uusiKahvi<=0) {
						JOptionPane.showMessageDialog(null, "Arvon on oltava nollan ja 250 v�lill�!");
						continue;
					}
				}

			}
		});

		menuItem2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean kysely2;

				while (kysely2 = true) {
					String uusiArvo = JOptionPane.showInputDialog( "Anna uusi arvo: ");
					int uusiTee = Integer.parseInt(uusiArvo);
					if (uusiTee < 250 && uusiTee > 0) {
						ja.setTee(uusiTee);
						teetaJaljella.setText("Teet� j�ljell�: " + uusiTee);
						teetaJaljella.setForeground(Color.BLACK);
						if (uusiTee <= 20) {
							teetaJaljella.setForeground(Color.RED);
						}
						break;
					} else if(uusiTee>=250 || uusiTee<=0) {
						JOptionPane.showMessageDialog(null, "Arvon on oltava nollan ja 250 v�lill�!");
						continue;
					}
				}

			}
		});

		menuItem3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean kysely;

				while (kysely = true) {
					String uusiArvo = JOptionPane.showInputDialog( "Anna uusi arvo: ");
					int uusiKaakao = Integer.parseInt(uusiArvo);
					if (uusiKaakao < 250 && uusiKaakao > 0) {
						ja.setKaakao(uusiKaakao);
						kaakaotaJaljella.setText("Kaakaota j�ljell�: " + uusiKaakao);
						kaakaotaJaljella.setForeground(Color.BLACK);
						if (uusiKaakao <= 20) {
							kaakaotaJaljella.setForeground(Color.RED);
						}
						break;
					} else if(uusiKaakao>=250 || uusiKaakao<=0) {
						JOptionPane.showMessageDialog(null, "Arvon on oltava nollan ja 250 v�lill�!");
						continue;
					}
				}

			}
		});

		// teht�v� 9
		menuItem4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Sarjallistamista.kirjoitaTiedostoon(ja);
				} catch (Exception j) {
					System.out.println("Tallentaminen ei onnistu");
				}
			}
		});

		menuItem5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					JuomaAutomaatti uusi = Sarjallistamista.lueTiedostosta();
					int kahvi = uusi.getKahvi();
					ja.setKahvi(kahvi);
					kahviaJaljella.setText("Kahvia j�ljell�: " + kahvi);
					kahviaJaljella.setForeground(Color.BLACK);

					int tee = uusi.getTee();
					ja.setTee(tee);
					teetaJaljella.setText("Teet� j�ljell�: " + tee);
					teetaJaljella.setForeground(Color.BLACK);

					int kaakao = uusi.getKaakao();
					ja.setKaakao(kaakao);
					kaakaotaJaljella.setText("Kaakaota j�ljell�: " + kaakao);
					kaakaotaJaljella.setForeground(Color.BLACK);

				} catch (Exception q) {
					System.out.println("Luku ei onnistunut.");
				}
			}
		});

		// teht�v� 10
		menuItem6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});

		// teht�v� 11
		tietoMenu1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Versiotiedot ikkuna = new Versiotiedot();
				ikkuna.setVisible(true);
			}
		});

		tietoMenu2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		});
	}
}
