import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet
 */
@WebServlet("/Servlet")
public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			//luodaan tietokantasovellus
			Connection con= DriverManager.getConnection("jdbc:mysql://35.228.110.190/elokuvatietokanta","root","root");
			
			if(con!=null) {
				System.out.println("Yhteys on muodostettu!");
			}
			
			Statement stmt=con.createStatement();
		    ResultSet rs=stmt.executeQuery("SELECT * FROM elokuvat");
		    while(rs.next())
		  System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3)+ "  " +rs.getString(4)+"  "+rs.getInt(5));
		    con.close();
			//SELECT * FROM elokuvatietokanta.elokuvat;
			
			//varaudutaan virheisiin
		}catch(Exception e) {
			System.out.println("Tapahtui virhe!");
			System.out.println("e");
		}
	}

}
